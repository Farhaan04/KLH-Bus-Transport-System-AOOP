package com.example.aoopproject;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class DetailsPage extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_details_page);
    }
}