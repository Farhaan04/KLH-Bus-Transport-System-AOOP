package com.example.aoopproject;

public class Upd_location {
    public double latitude,longitude;
    public Upd_location(){

    }
    public Upd_location(double latitude,double longitude){
        this.latitude=latitude;
        this.longitude=longitude;
    }

}
